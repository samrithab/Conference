**** CSC207 Phase 1 - Conference System ****

Please add any instructions for how to test your features, and comments about how you resolved any ambiguity in the
specification.

** General Instructions **
Program users are given numbered menus to request actions and follow text prompts that direct further input.
You can input a variety of valid and invalid inputs--the program should handle the invalid ones.
To test the features, go through the menus, entering numbers and then information as directed.
Default information is detailed at the end of this readme.
Here is a suggested sequence of how to go about testing:
   (1) Log into any/all of the provided user accounts.
   (2) Select the various "view" options to verify that the default information exists in the program.
   (3) Modify the existing information (e.g. sign up/cancel attendance/search for events, reply to messages)
   (4) Add new information (e.g. create new accounts, rooms, and events; add/remove friends; send messages)

The following descriptions involve design choices that we made based on the specification.

** General Choices **
Any type of user can do all the actions that an Attendee can do. This is enforced by having a default
menu but showing a specialized menu to specific user types.

** Messaging **
Every type of user can reply to any message that was sent to them. Every type of user can message friends that they
have added to their friends list. This is the only messaging that Attendees can do (so Attendees cannot add Organizers
to their friends list). Try also logging in as an Organizer or as a Speaker to test the messaging functionality
specific to those types of users.

** Signup System **
All types of user can sign up to attend an event or cancel their attendance in an event they are signed up for
by entering the title of an event. Additionally, they can search for specific events that contain a certain title,
speaker, or start time.

** Rooms **
Conferences have rooms in which events take place. Rooms are uniquely identified by their RoomID (their room number),
so 2 rooms cannot have the same room number. A room cannot have multiple events at the same time, nor have events
with an event capacity larger than the room capacity.

** Gateways **
Saved data on users, events, messages, and rooms is loaded from file every time the program begins.
Importantly, data is only saved to file when the user exits the program via the menu options.
Therefore, if you do not want to save the changes you made during program execution (applicable if you want to
use the default information each time), end the program using IntelliJ instead of the menu.

** Events **
Events are uniquely identified by their title. Events are created with no speakers scheduled within them.
Only Organizers can create events and assign a speaker to an event.

*******************************************************************
** Default Information **
To load in the default information, ensure that the .ser files containing the default information are in ~/data
where ~ is the root directory of the project.

**** User Accounts ****
username: Tiffanie  password: Truong    userType: Attendee
username: Rudy      password: Ariaz     userType: Organizer
username: Matthew   password: Zhu       userType: Speaker
Rudy is friends with Tiffanie and Matthew.
Matthew is friends with Tiffanie.

**** Rooms ****
roomID: 1   capacity: 2
roomID: 2   capacity: 4
roomID: 3   capacity: 6

**** Events ****
title: Manifolds     start time: 9      roomID: 1   capacity: 2
title: Morphology    start time: 9      roomID: 2   capacity: 3
title: Modern Music  start time: 10     roomID: 2   capacity: 4
Rudy is signed up for Manifolds.
Tiffanie is signed up for Morphology.
Matthew is scheduled as the speaker for Morphology and Modern Music.

**** Messages ****
There is a message from Rudy to both Tiffanie and Matthew.
There is a reply to that message from Matthew.
