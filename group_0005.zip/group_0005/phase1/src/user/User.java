package user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * The <code>User</code> class represents a user attending the conference and consequently a potential client of
 * the program.
 */
class User implements Serializable {

    private final String username;
    private final String password;
    private final UserType userType;
    private final List<String> friends;

    /**
     * Constructs a new <code>User</code> with an initially empty friends list.
     *
     * @param username the username associated with this user's account
     * @param password the password associated with this user's account
     * @param userType the type of this user, representing their role in the conference
     */
    public User(String username, String password, UserType userType) {
        this.username = username;
        this.password = password;
        this.userType = userType;
        this.friends = new ArrayList<>();
    }

    /**
     * Gets the username associated with this user's account.
     *
     * @return the user's username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Gets the password associated with this user's account.
     *
     * @return the user's password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Gets the list of usernames corresponding to friends in this user's friends list.
     *
     * @return the list of friends in this user's friends list
     */
    public List<String> getFriends() {
        return friends;
    }

    /**
     * Gets the type of this <code>User</code>.
     *
     * @return the type associated with this <code>User</code>
     */
    public UserType getUserType() {
        return userType;
    }

    /**
     * Adds the given friend to this user's friends list.
     *
     * @param friend the username of the friend to add to this user's friends list
     */
    public void addFriend(String friend) {
        friends.add(friend);
    }

    /**
     * Removes the given friend from this user's friends list.
     *
     * @param friend the username of the friend to remove from this user's friends list
     */
    public void removeFriend(String friend) {
        friends.remove(friend);
    }
}