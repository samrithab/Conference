package user;

import system.ConsolePresenter;

import java.util.EnumMap;
import java.util.List;

/**
 * The UserPresenter class is responsible for displaying messages related to actions involving user accounts
 * on the screen for the client. These messages include prompts, errors, success confirmations, and menus.
 * This responsibility implies that the class currently acts as a Presenter and a UI.
 */
class UserPresenter extends ConsolePresenter<UserPrompts> {

    /**
     * Returns an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     *
     * @return an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     */
    @Override
    protected EnumMap<UserPrompts, String> initializeMessages() {
        EnumMap<UserPrompts, String> m = new EnumMap<>(UserPrompts.class);
        m.put(UserPrompts.ACTION_PROMPT, "Please select an action.");
        m.put(UserPrompts.ADD_FRIEND_PROMPT, "Please enter the username of the user you would like to add:");
        m.put(UserPrompts.REMOVE_FRIEND_PROMPT, "Please enter the username of the user you would like to remove:");
        m.put(UserPrompts.INVALID_INPUT_ERROR, "Sorry, the input you entered was not valid.");
        m.put(UserPrompts.USER_NOT_FOUND_ERROR, "Sorry, that user does not exist.");
        m.put(UserPrompts.ALREADY_FRIENDS_ERROR, "Sorry, you are already friends with this person.");
        m.put(UserPrompts.NOT_FRIENDS_ERROR, "Sorry, this person is not in your friends list!");
        m.put(UserPrompts.EMPTY_FRIENDS_LIST_ERROR,
                "Sorry, you currently do not have any friends in your friends list.");
        m.put(UserPrompts.ADD_YOURSELF_ERROR, "Sorry, you cannot add yourself to your own friends list.");
        m.put(UserPrompts.ATTENDEE_ADD_ORGANIZER_ERROR, "Sorry, you cannot add an Organizer to your friends list.");
        m.put(UserPrompts.ADD_FRIEND_SUCCESS, "You have successfully added this user to your friends list.");
        m.put(UserPrompts.REMOVE_FRIEND_SUCCESS, "You have successfully removed this user from your friends list.");
        return m;
    }

    /**
     * Prints the menu of options related to managing a user's friends list to the screen.
     */
    public void displayFriendsListMenu() {
        System.out.println("===== FRIENDS LIST ACTIONS ======");
        System.out.println("1 - View your friends list");
        System.out.println("2 - Add a user to your friends list");
        System.out.println("3 - Remove a user from your friends list");
        System.out.println("4 - Return to the main menu");
    }

    /**
     * Prints all the usernames of accounts in the user's friends list to the screen.
     *
     * @param friendsList the list of usernames to be printed to the screen
     */
    public void displayFriendsList(List<String> friendsList) {
        System.out.println("===== YOUR FRIENDS LIST =====");
        if (friendsList.isEmpty()) {
            display(UserPrompts.EMPTY_FRIENDS_LIST_ERROR);
        } else {
            for (int i = 0; i < friendsList.size(); i++) {
                System.out.print(friendsList.get(i));
                if (i != friendsList.size() - 1) {   /* add a comma if not at last username */
                    System.out.print(", ");
                }
            }
        }
        System.out.println("\n");
    }

    /**
     * Prints the given list of usernames to the screen.
     *
     * @param usernames the list of usernames to be printed to the screen.
     * @param userType  the type of user being displayed
     */
    public void displayUsernames(List<String> usernames, UserType userType) {
        System.out.println("===== ALL " + userType.toString() + " USERNAMES =====");
        System.out.println(String.join("\n", usernames));
    }
}