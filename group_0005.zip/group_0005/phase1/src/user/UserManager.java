package user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * The <code>UserManager</code> class is responsible for storing the data of all existing users during program execution
 * and processes requests involving user accounts.
 */
public class UserManager implements Serializable {

    private final List<User> users;

    /**
     * Constructs a manager responsible for user account data that is initialized storing an empty list of users.
     */
    public UserManager() {
        this.users = new ArrayList<>();
    }

    /**
     * Returns the <code>User</code> whose username matches the given username.
     * Precondition: username is the username of an existing <code>User</code>
     *
     * @param username the username of the desired User
     * @return the instance of <code>User</code> associated with username
     * @throws UserNotFoundException if the given username is not the username of an existing user
     */
    private User getUserWithUsername(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username))
                return user;
        }
        throw new UserNotFoundException(String.format("User with username %s does not exist.", username));
    }

    /**
     * Adds a new <code>User</code> with the given <code>username</code>, <code>password</code>, and
     * <code>UserType</code> to the list of existing <code>Users</code>.
     *
     * @param username the username of the <code>User</code> to be added to the list of existing users
     * @param password the password of the <code>User</code> to be added to the list of existing users
     * @param userType the <code>UserType</code> of the <code>User</code> to be added to the list of existing users
     */
    public void addUser(String username, String password, UserType userType) {
        users.add(new User(username, password, userType));
    }

    /**
     * Returns true if there exists a <code>User</code> with the specified username.
     *
     * @param username the username of a potential existing <code>User</code>
     * @return true if there exists a <code>User</code> with the specified username
     */
    public boolean userExists(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username))
                return true;
        }
        return false;
    }

    /**
     * Returns true if there exists a <code>User</code> whose login credentials match the given username and password.
     *
     * @param username the username of a potential existing <code>User</code>
     * @param password the password of a potential existing <code>User</code>
     * @return true if there exists a <code>User</code> whose credentials match the given username and password
     */
    public boolean passwordMatches(String username, String password) {
        if (!userExists(username)) {
            return false;
        }
        User user = getUserWithUsername(username);
        return user.getPassword().equals(password);
    }

    /**
     * Returns the <code>UserType</code> of a <code>User</code> who has the given username.
     * Precondition: username is the username of an existing <code>User</code>
     *
     * @param username the username of the desired <code>User</code>
     * @return the <code>UserType</code> of a <code>User</code> who has the given username
     */
    public UserType getUserType(String username) {
        return getUserWithUsername(username).getUserType();
    }

    /**
     * Returns true if there exists a <code>User</code> whose username is <code>user</code> and
     * is friends with a <code>User</code> whose username is <code>potentialFriend</code>.
     *
     * @param user            the username of the user's whose friends list is being checked
     * @param potentialFriend the username of the potential friend in the first user's friends list
     * @return true if there exists a <code>User</code> whose username is <code>user</code> and is friends with a <code>User</code>
     * whose username is <code>potentialFriend</code>
     */
    public boolean areFriends(String user, String potentialFriend) {
        if (!userExists(user) || !userExists(potentialFriend)) {
            return false;
        }
        return getUserWithUsername(user).getFriends().contains(potentialFriend);
    }

    /**
     * Adds the <code>User</code> with username <code>addedUser</code> to the friends list of the user with
     * username <username>requestingUser</username>.
     * <p>
     * Precondition: <code>requestingUser</code> and <code>addedUser</code> are the usernames of existing
     * <code>Users</code>, and <code>addedUser</code> is not in <code>requestingUser</code>'s friends list
     *
     * @param requestingUser the username of the user whose friends list is being modified
     * @param addedUser      the username of the user to be added to the first user's friends list
     */
    public void addFriend(String requestingUser, String addedUser) {
        getUserWithUsername(requestingUser).addFriend(addedUser);
    }

    /**
     * Removes the <code>User</code> with username <code>removedUser</code> from the friends list of the
     * <code>User</code> with username <code>requestingUser</code>.
     * <p>
     * Precondition: <code>requestingUser</code> and <code>removedUser</code> are the usernames of existing
     * <code>Users</code>, and <code>removedUser</code> is exists in  <code>requestingUser</code>'s friends list
     *
     * @param requestingUser the username of the user whose friends list is being modified
     * @param removedUser    the username of the user to be added to the first user's friends list
     */
    public void removeFriend(String requestingUser, String removedUser) {
        getUserWithUsername(requestingUser).removeFriend(removedUser);
    }

    /**
     * Returns true if the <code>User</code> with the given username has an empty friends list.
     * Precondition: <code>username</code> is the username of an existing <code>User</code>
     *
     * @param username the username of the <code>User</code>  whose friends list is being checked
     * @return true if the <code>User</code> with the given username has an empty friends list
     */
    public boolean hasEmptyFriendsList(String username) {
        return getUserWithUsername(username).getFriends().size() == 0;
    }

    /**
     * Returns a list of usernames corresponding to accounts in the given user's friends list.
     *
     * @param curUser the username of the <code>User</code> whose friends list is being accessed
     * @return a list of usernames corresponding to accounts in the user's friends list.
     */
    public List<String> getFriendsList(String curUser) {
        return getUserWithUsername(curUser).getFriends();
    }

    /**
     * Returns a list of usernames corresponding to users that are of the specified <code>UserType</code> .
     *
     * @param userType the type of <code>User</code> such that usernames of users of that type will be returned
     * @return a list of usernames corresponding to <code>Users</code> that are of userType
     */
    public List<String> getAllUsernamesOfType(UserType userType) {
        List<String> usernames = new ArrayList<>();
        for (User user : users) {
            if (user.getUserType() == userType) {
                usernames.add(user.getUsername());
            }
        }
        return usernames;
    }
}
