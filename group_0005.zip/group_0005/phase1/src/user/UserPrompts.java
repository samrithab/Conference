package user;

/**
 * This enum contains keys specifying the one-line text prompts that can be printed
 * to console during interactions in <code>UserController</code>.
 */
enum UserPrompts {

    ACTION_PROMPT,
    ADD_FRIEND_PROMPT,
    REMOVE_FRIEND_PROMPT,
    INVALID_INPUT_ERROR,
    USER_NOT_FOUND_ERROR,
    ALREADY_FRIENDS_ERROR,
    NOT_FRIENDS_ERROR,
    EMPTY_FRIENDS_LIST_ERROR,
    ADD_YOURSELF_ERROR,
    ATTENDEE_ADD_ORGANIZER_ERROR,
    ADD_FRIEND_SUCCESS,
    REMOVE_FRIEND_SUCCESS
}
