package event;

import room.RoomManager;

import java.util.*;

/**
 * The <code>EventController</code> class is responsible for processing requests involving event data.
 * These requests include viewing, adding, and signing up for events. Requests to find information about specific
 * events are also managed by this class.
 */
public class EventController {

    private final EventManager eventManager;
    private final EventPresenter eventPresenter;
    private final RoomManager roomManager;
    private final Scanner in;

    /**
     * Constructs a controller to process the current user's requests involving events in the conference.
     *
     * @param eventManager the manager responsible for event data during program execution
     * @param roomManager  the manager responsible for room information during program execution
     * @param in           the instance of Scanner currently taking user input from the Console
     */
    public EventController(EventManager eventManager, RoomManager roomManager, Scanner in) {
        this.eventManager = eventManager;
        this.eventPresenter = new EventPresenter();
        this.roomManager = roomManager;
        this.in = in;
    }

    /**
     * Displays the list of all events scheduled in the conference.
     */
    public void displayCompleteSchedule() {
        eventPresenter.display(EventPrompts.EVENT_SCHEDULE_DISPLAYED);
        List<String> eventStrings = eventManager.getStringRepresentations();
        eventPresenter.displaySchedule(eventStrings);
    }

    /**
     * Displays the list of events that given user is signed up for.
     */
    public void displayUserSchedule(String username) {
        eventPresenter.display(EventPrompts.EVENT_LIST_DISPLAYED);
        List<String> eventTitles = eventManager.getEventsByUser(username);
        List<String> eventStrings = eventManager.getStringRepresentations(eventTitles);
        eventPresenter.displaySchedule(eventStrings);
    }

    /**
     * Displays the list of events that the given speaker is scheduled to speak at.
     */
    public void displaySpeakerEvents(String speakerName) {
        eventPresenter.display(EventPrompts.SPEAKER_SCHEDULE_DISPLAYED);
        List<String> eventTitles = eventManager.getEventsBySpeaker(speakerName);
        List<String> eventStrings = eventManager.getStringRepresentations(eventTitles);
        eventPresenter.displaySchedule(eventStrings);
    }

    /**
     * Gets a list of usernames corresponding to attendees signed up for at least one event that the given
     * speaker is speaking at.
     *
     * @param speakerName username of the speaker for the event
     * @return list of attendees for the event based on the speaker
     */
    public List<String> getAttendeesForEventsBySpeaker(String speakerName) {
        HashSet<String> attendeesSet = new HashSet<>();
        List<String> eventsBySpeaker = eventManager.getEventsBySpeaker(speakerName);
        for (String event : eventsBySpeaker) {
            attendeesSet.addAll(eventManager.getAttendees(event));
        }
        return new ArrayList<>(attendeesSet);
    }

    /**
     * Gets a list of usernames corresponding to attendees signed up for a given event.
     *
     * @param eventTitle the title of the event whose attendees are returned
     * @return a list of usernames corresponding to attendees signed up for the event <code>eventTitle</code>
     */
    public List<String> getAttendeesForEvent(String eventTitle) {
        return eventManager.getAttendees(eventTitle);
    }

    /**
     * Returns true iff the event with the given title exists in the conference.
     *
     * @param title title of the event
     * @return true if the event exists, false otherwise
     */
    public boolean eventExists(String title) {
        return eventManager.eventExists(title);
    }

    /**
     * Returns true iff the given event has a speaker assigned
     *
     * @param eventTitle the title of the event
     * @return true if the event has a speaker, false otherwise
     */
    public boolean eventHasSpeaker(String eventTitle) {
        return eventManager.getSpeaker(eventTitle) != null;
    }

    /**
     * Returns true iff the given speaker is already booked for the start time of the given event
     *
     * @param speakerUsername the username of the speaker
     * @param eventTitle      the title of the event
     * @return true if the speaker is booked at the start time of the event, false otherwise
     */
    public boolean speakerIsBookedDuringEvent(String speakerUsername, String eventTitle) {
        return eventManager.speakerIsBooked(speakerUsername, eventManager.getStartTime(eventTitle));
    }

    /**
     * Sets the speaker for the given event.
     *
     * @param eventTitle  the title of the event
     * @param speakerName the username of the speaker
     */
    public void setSpeaker(String eventTitle, String speakerName) {
        eventManager.setSpeaker(eventTitle, speakerName);
    }

    /**
     * Processes an organizer's request to add a new event to the conference.
     * This method accepts user input describing the new event, checks if all the information is valid,
     * and calls for the creation of the new event if so.
     */
    public void addNewEvent() {
        // Process title
        String title = readEventTitle();
        if (invalidTitle(title)) {
            return;
        }
        // Process time
        OptionalInt startTime = readInteger(EventPrompts.EVENT_START_TIME_PROMPT);
        if (!startTime.isPresent() || invalidStartTime(startTime.getAsInt())) {
            return;
        }
        // Process event capacity
        OptionalInt eventCapacity = readInteger(EventPrompts.EVENT_CAPACITY_PROMPT);
        if (!eventCapacity.isPresent() || invalidEventCapacity(eventCapacity.getAsInt())) {
            return;
        }
        // Process room ID
        OptionalInt roomID = readInteger(EventPrompts.EVENT_ROOM_ID_PROMPT);
        if (!roomID.isPresent() ||
                invalidRoomForEvent(roomID.getAsInt(), startTime.getAsInt(), eventCapacity.getAsInt())) {
            return;
        }
        processEventAddition(title, startTime.getAsInt(), roomID.getAsInt(), eventCapacity.getAsInt());
    }

    private void processEventAddition(String title, int startTime, int roomID, int eventCapacity) {
        eventManager.createEvent(title, startTime, roomID, eventCapacity);
        roomManager.addEventToRoom(roomID, title);
        roomManager.addBookedTimeToRoom(roomID, startTime);
        eventPresenter.display(EventPrompts.EVENT_CREATION_SUCCESS);
    }

    private OptionalInt readInteger(EventPrompts prompt) {
        eventPresenter.display(prompt);
        if (!in.hasNextInt()) {
            eventPresenter.display(EventPrompts.INPUT_NOT_INT_ERROR);
            in.nextLine();
            return OptionalInt.empty();
        }
        int input = in.nextInt();
        in.nextLine();
        return OptionalInt.of(input);
    }

    /**
     * Returns true if the given event title is an invalid title for a new event.
     * A title is invalid if there already exists an event with the given title.
     *
     * @param title the name of a potential new event
     * @return true if the given event title is an invalid title for a new event
     */
    private boolean invalidTitle(String title) {
        if (eventManager.eventExists(title)) {
            eventPresenter.display(EventPrompts.EVENT_EXISTS_ERROR);
            return true;
        }
        return false;
    }

    /**
     * Returns true if the given start time is a invalid time that a new event can be scheduled at.
     * A start time is invalid if it is not an integer between 9 and 17, representing an hour in 24-hour clock format.
     *
     * @param startTime an integer representing the hour in 24-hour clock format that an event starts at
     * @return true if the given time is an invalid start time for an event
     */
    private boolean invalidStartTime(int startTime) {
        if (startTime < 9 || startTime > 17) {
            eventPresenter.display(EventPrompts.TIME_ERROR);
            return true;
        }
        return false;
    }

    /**
     * Returns true if given room ID corresponds to a room that a new event cannot be scheduled in.
     * An event cannot be scheduled in a room if the room has an event scheduled in it at the given time or
     * the given number of attendees exceeds the room's maximum capacity.
     *
     * @param roomID       the room number of the room being checked
     * @param startTime    an integer representing the hour in 24-hour clock format
     * @param numAttendees the maximum number of attendees for an event being planned to be held in the given room
     * @return true if the room corresponds to a invalid room
     */
    private boolean invalidRoomForEvent(int roomID, int startTime, int numAttendees) {
        if (!roomManager.roomExists(roomID)) {
            eventPresenter.display(EventPrompts.ROOM_NOT_FOUND_ERROR);
            return true;
        } else if (roomManager.roomIsBooked(roomID, startTime)) {
            eventPresenter.display(EventPrompts.ROOM_IS_BOOKED);
            return true;
        } else if (numAttendees > roomManager.getCapacityOfRoom(roomID)) {
            eventPresenter.display(EventPrompts.EVENT_CAPACITY_TOO_LARGE_ERROR);
            return true;
        }
        return false;
    }

    /**
     * Returns true if the given event capacity corresponds to an an integer less than or equal to 0.
     *
     * @param eventCapacity the maximum number of attendees that can be signed up for an event
     * @return true if the event capacity corresponds to an integer less than or equal to 0
     */
    private boolean invalidEventCapacity(int eventCapacity) {
        if (eventCapacity <= 0) {
            eventPresenter.display(EventPrompts.INVALID_CAPACITY_ERROR);
            return true;
        }
        return false;
    }

    /**
     * Reads and returns a speaker name that the user enters.
     *
     * @return the speaker name entered by the user
     */
    public String readSpeaker() {
        eventPresenter.display(EventPrompts.EVENT_SPEAKER_PROMPT);
        return in.nextLine();
    }

    /**
     * Reads and returns an event title that the user enters.
     *
     * @return the event title entered by the user
     */
    public String readEventTitle() {
        eventPresenter.display(EventPrompts.EVENT_TITLE_PROMPT);
        return in.nextLine();
    }

    /**
     * Returns whether or not the speaker with name <code>speakerName</code> is speaking at the event called
     * <code>eventTitle</code>.
     * <p>
     * If <code>speakerName</code> is not a speaker or <code>eventTitle</code> is not the title
     * for an existing event, the method will return false.
     *
     * @param speakerName the name of the speaker to be checked
     * @param eventTitle  the title of the event to be checked
     * @return <code>true</code> if and only if an event with title <code>eventTitle</code> exists
     */
    public boolean isSpeakerForEvent(String speakerName, String eventTitle) {
        if (eventManager.getEventsBySpeaker(speakerName).contains(eventTitle)) {
            return true;
        }
        eventPresenter.display(EventPrompts.SPEAKER_NOT_FOR_EVENT);
        return false;
    }

    /**
     * Schedules the speaker <code>speaker</code> to an event entered by the user, if possible. Displays an appropriate
     * error message if this operation cannot be completed, which is the case if
     * <ul>
     *     <li>The event that the user has entered does not exist, or</li>
     *     <li>The event that the user has entered already has a speaker, or</li>
     *     <li>The speaker with username <code>speaker</code> is already booked at the time of the event.</li>
     * </ul>
     *
     * @param speaker   the speaker's username
     * @param isSpeaker <code>true</code> if and only if <code>speaker</code> is the username of a speaker
     */
    public void scheduleSpeakerToEvent(String speaker, boolean isSpeaker) {
        if (!isSpeaker) {
            eventPresenter.display(EventPrompts.NO_SUCH_SPEAKER_USERNAME);
            return;
        }
        String eventTitle = readEventTitle();
        EventPrompts result = validateScheduling(speaker, eventTitle);
        if (result == EventPrompts.SPEAKER_SUCCESSFULLY_ASSIGNED) {
            setSpeaker(eventTitle, speaker);
        }
        eventPresenter.display(result);
    }

    private EventPrompts validateScheduling(String speaker, String eventTitle) {
        if (!eventExists(eventTitle)) {
            return EventPrompts.EVENT_NOT_FOUND;
        } else if (eventHasSpeaker(eventTitle)) {
            return EventPrompts.EVENT_HAS_SPEAKER;
        } else if (speakerIsBookedDuringEvent(speaker, eventTitle)) {
            return EventPrompts.SPEAKER_ALREADY_BOOKED;
        }
        return EventPrompts.SPEAKER_SUCCESSFULLY_ASSIGNED;
    }

}

