package event;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * The <code>EventManager</code> class is responsible for storing event data during program execution. It modifies and
 * accesses information regarding both individual events and the complete list of events as directed.
 */
public class EventManager implements Serializable {

    private final List<Event> events;
    private final EventFactory eventFactory;

    /**
     * Constructs a manager responsible for event data that is initialized storing an empty list of events.
     */
    public EventManager() {
        this.events = new ArrayList<>();
        this.eventFactory = new EventFactory();
    }

    /**
     * Gets the <code>Event</code> object corresponding to the given title.
     * Precondition: a <code>Event</code> object with title <code>title</code> already exists.
     *
     * @param title the unique title of the <code>Event</code> object to retrieve
     * @return the unique <code>Event</code> object with title <code>title</code>
     * @throws EventNotFoundException if an <code>Event</code> object with title <code>title</code> does not exist
     */
    private Event getEventWithTitle(String title) {
        for (Event event : events) {
            if (event.getTitle().equals(title)) {
                return event;
            }
        }
        throw new EventNotFoundException();
    }

    /**
     * Creates a new event in the conference with the given information.
     *
     * @param title         the title of the event being created
     * @param roomID        the ID of the room the event will be held at
     * @param startTime     an integer representing the hour the event starts at (in 24-hour clock format)
     * @param eventCapacity the maximum number of people that can sign up for events
     */
    public void createEvent(String title, int startTime, int roomID, int eventCapacity) {
        events.add(eventFactory.getEvent(title, startTime, roomID, eventCapacity));
    }

    /**
     * Returns a list of the titles of all events in the conference.
     *
     * @return a list of the titles of all events
     */
    public List<String> getEventList() {
        List<String> titles = new ArrayList<>();
        for (Event event : events) {
            titles.add(event.getTitle());
        }
        return titles;
    }

    /**
     * Returns a list of string representations for the given events. The information in the returned list
     * corresponds to the same order of events in the list that is passed in.
     *
     * @param eventTitles the list of events to get string representations for
     * @return a list of string representations for the given events
     */
    public List<String> getStringRepresentations(List<String> eventTitles) {
        List<String> strings = new ArrayList<>(eventTitles.size());
        for (Event event : events) {
            int index = eventTitles.indexOf(event.getTitle());
            if (index != -1) {
                strings.add(index, event.toString());
            }
        }
        return strings;
    }

    /**
     * Returns a list of string representations for all events in the conference
     *
     * @return a list of string representations for all events in the conference
     */
    public List<String> getStringRepresentations() {
        return getStringRepresentations(getEventList());
    }

    /**
     * Returns the start time for the given event.
     * Precondition: an <code>Event</code> object with the title <code>eventTitle</code> already exists.
     *
     * @param eventTitle the title of the event
     * @return the start time of the event
     */
    public int getStartTime(String eventTitle) {
        return getEventWithTitle(eventTitle).getStartTime();
    }

    /**
     * Returns the username of the speaker for the given event.
     * If the given event has no speaker, this method returns null.
     * Precondition: an <code>Event</code> object with the title <code>eventTitle</code> already exists.
     *
     * @param eventTitle the title of the event
     * @return the username of the speaker for the event if it has a speaker, otherwise null
     */
    public String getSpeaker(String eventTitle) {
        return getEventWithTitle(eventTitle).getSpeaker();
    }

    /**
     * Sets the speaker for the given event.
     * Precondition: an <code>Event</code> object with the title <code>eventTitle</code> already exists
     *
     * @param eventTitle  the title of the event
     * @param speakerName the username of the speaker
     */
    public void setSpeaker(String eventTitle, String speakerName) {
        getEventWithTitle(eventTitle).setSpeaker(speakerName);
    }

    /**
     * Returns a list of events that the given speaker is the scheduled to speak at.
     *
     * @param speakerName the username of the speaker
     * @return a list of events that the given speaker is the scheduled to speak at
     */
    public List<String> getEventsBySpeaker(String speakerName) {
        List<String> eventsBySpeaker = new ArrayList<>();
        for (Event event : events) {
            String curSpeaker = event.getSpeaker();
            if (curSpeaker != null && curSpeaker.equals(speakerName)) {
                eventsBySpeaker.add(event.getTitle());
            }
        }
        return eventsBySpeaker;
    }

    /**
     * Returns a list of the events that the given user is signed up for.
     *
     * @param username the username of the user whose event schedule is being checked
     * @return a list of the events that the given user is signed up for
     */
    public List<String> getEventsByUser(String username) {
        List<String> eventsByUser = new ArrayList<>();
        for (Event event : events) {
            if (event.getAttendees().contains(username)) {
                eventsByUser.add(event.getTitle());
            }
        }
        return eventsByUser;
    }

    /**
     * Returns true if the given speaker is booked to speak at an event at the given time of interest.
     *
     * @param speaker   the username of the speaker whose event schedule is being checked
     * @param startTime an integer representing an hour in 24-hour clock format that an event starts at
     * @return true if the speaker is booked at the given time
     */
    boolean speakerIsBooked(String speaker, int startTime) {
        for (Event event : events) {
            String curSpeaker = event.getSpeaker();
            if (curSpeaker != null && curSpeaker.equals(speaker) && event.getStartTime() == startTime) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns true if the event with the given title has less users signed up than the maximum number of users
     * that can sign up.
     *
     * @param eventTitle the title of the event whose attendance is being checked
     * @return true if the event currently has less users signed up than the maximum number of users that can sign up
     */
    public boolean isNotFull(String eventTitle) {
        Event event = getEventWithTitle(eventTitle);
        return event.getAttendees().size() < event.getCapacity();
    }

    /**
     * Adds the user with the given username to the attendee list of the event with the given title if the
     * event is not at maximum capacity.
     *
     * @param eventTitle the title of the event an attendee wants to sign up for
     * @param username   the username of the attendee
     * @return true if the attendee was successfully added to the list
     */
    public boolean addAttendee(String eventTitle, String username) {
        if (isNotFull(eventTitle)) {
            getEventWithTitle(eventTitle).addAttendee(username);
            return true;
        }
        return false;
    }

    /**
     * Removes the user with the given username from the attendee list of the event with the given title if
     * the user is signed up for the event.
     *
     * @param eventTitle the event an attendee will no longer be attending
     * @param username   the username of the attendee
     * @return true if the attendee was successfully removed from the attendee list,
     * false if the attendee was not found in the list
     */
    public boolean removeAttendee(String eventTitle, String username) {
        Event event = getEventWithTitle(eventTitle);
        if (event.getAttendees().contains(username)) {
            event.removeAttendee(username);
            return true;
        }
        return false;
    }

    /**
     * Returns true if there exists an event with the given title.
     *
     * @param title the title of the event whose existence is being checked
     * @return true if the title exists in the list of all events, false otherwise
     */
    boolean eventExists(String title) {
        for (Event event : events) {
            if (event.getTitle().equals(title)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Gets a list of usernames corresponding to attendees that are signed up for the event with the given title.
     *
     * @param eventTitle the title of the event whose list of attendees is being checked
     * @return a list of usernames corresponding to attendees that are signed up for the event with the given title
     */
    public List<String> getAttendees(String eventTitle) {
        return getEventWithTitle(eventTitle).getAttendees();
    }

}
