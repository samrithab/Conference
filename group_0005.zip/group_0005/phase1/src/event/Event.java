package event;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * The <code>Event</code> class represents a event in the conference regulated by the program.
 */
class Event implements Serializable {

    private final String title;
    private final int startTime;
    private final int roomID;
    private final int capacity;
    private final List<String> attendees;
    private String speakerUsername;

    /**
     * Constructs an <code>Event</code> object associated with the given information, a generated event ID, and an
     * initially empty list of attendees.
     *
     * @param title     the name of the event. Event titles are unique.
     * @param startTime an integer representing the hour in 24-hour clock format that the event starts at
     * @param roomID    the ID of the room in which the event is held
     * @param capacity  the maximum number of attendees that can be signed up for the event
     */
    public Event(String title, int startTime, int roomID, int capacity) {
        this.title = title;
        this.startTime = startTime;
        this.roomID = roomID;
        this.capacity = capacity;
        this.speakerUsername = null;
        this.attendees = new ArrayList<>();
    }

    /**
     * Gets the start time of this event.
     *
     * @return an integer representing the hour in 24-hour clock format that the event starts at
     */
    public int getStartTime() {
        return startTime;
    }

    /**
     * Gets the username of the speaker for this event.
     * If the event has no speaker, returns null.
     *
     * @return the username of the speaker for this event if it has a speaker, otherwise null
     */
    public String getSpeaker() {
        return speakerUsername;
    }

    /**
     * Sets the speaker for this event.
     *
     * @param username the username of the speaker
     */
    public void setSpeaker(String username) {
        speakerUsername = username;
    }

    /**
     * Gets the name of this event.
     *
     * @return the name of this event
     */
    public String getTitle() {
        return title;
    }

    /**
     * Gets the list of usernames corresponding to attendees signed up for this event.
     *
     * @return the list of attendees that have signed up for this event
     */
    public List<String> getAttendees() {
        return attendees;
    }

    /**
     * Adds the given attendee to this event's list of attendees.
     *
     * @param username the username of the attendee to add to this event's list of attendees
     */
    public void addAttendee(String username) {
        attendees.add(username);
    }

    /**
     * Removes the given attendee from this event's list of attendees.
     *
     * @param username the username of the attendee being removed from this events list of attendees
     */
    public void removeAttendee(String username) {
        attendees.remove(username);
    }

    /**
     * Gets the capacity of this event.
     *
     * @return the maximum number of attendees that can sign up for this event
     */
    public int getCapacity() {
        return this.capacity;
    }

    /**
     * Returns a string representation of the event. This information includes the title, speaker,
     * start time, and room number of the event, each shown on a new line.
     *
     * @return the string representation of this event
     */
    @Override
    public String toString() {
        return "Event: " + title + "\n" +
                "Speaker: " + speakerUsername + "\n" +
                "Start Time: " + startTime + "\n" +
                "Room: " + roomID + "\n";
    }
}
