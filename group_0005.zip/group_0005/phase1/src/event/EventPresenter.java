package event;

import system.ConsolePresenter;

import java.util.EnumMap;
import java.util.List;

/**
 * The EventPresenter class is responsible for displaying messages related to events and event management.
 * These messages include prompts, errors, success confirmations, and menus.
 * This responsibility implies that the class currently acts as a Presenter and a UI.
 */
class EventPresenter extends ConsolePresenter<EventPrompts> {

    /**
     * Returns an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     *
     * @return an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     */
    @Override
    protected EnumMap<EventPrompts, String> initializeMessages() {
        EnumMap<EventPrompts, String> m = new EnumMap<>(EventPrompts.class);
        m.put(EventPrompts.EVENT_TITLE_PROMPT, "Please enter the title of the event:");
        m.put(EventPrompts.EVENT_SPEAKER_PROMPT, "Please enter the username of the speaker:");
        m.put(EventPrompts.EVENT_HAS_SPEAKER, "This event already has a speaker. Please try again.");
        m.put(EventPrompts.SPEAKER_ALREADY_BOOKED, "This speaker is already booked at the time of this event. " +
                "Please try again.");
        m.put(EventPrompts.SPEAKER_SUCCESSFULLY_ASSIGNED, "The speaker has successfully been assigned to this event.");
        m.put(EventPrompts.NO_SUCH_SPEAKER_USERNAME, "There is no speaker with that username. Please try again.");
        m.put(EventPrompts.EVENT_START_TIME_PROMPT,
                "Please enter the start time of the event (an integer in 24-hour format):");
        m.put(EventPrompts.EVENT_ROOM_ID_PROMPT, "Please enter the room number of the event room:");
        m.put(EventPrompts.EVENT_CAPACITY_PROMPT,
                "Please enter the maximum people able to sign up for the event:");
        m.put(EventPrompts.EVENT_NOT_FOUND, "There is no such event. Please try again.");
        m.put(EventPrompts.SPEAKER_NOT_FOR_EVENT, "You are not a speaker for this event. Please try again.");
        m.put(EventPrompts.EVENT_EXISTS_ERROR, "Sorry, this event with this title already exists.");
        m.put(EventPrompts.NOT_REGISTERED_IN_EVENT,
                "You are not registered in this event. Please try again.");
        m.put(EventPrompts.EVENT_SCHEDULE_DISPLAYED, "This is the schedule of all events:");
        m.put(EventPrompts.EVENT_LIST_DISPLAYED, "This is the schedule of events you are signed up for:");
        m.put(EventPrompts.EVENT_CREATION_SUCCESS, "The event was successfully added to the conference.");
        m.put(EventPrompts.ROOM_NOT_FOUND_ERROR, "Sorry, this room does not exist in the conference.");
        m.put(EventPrompts.TIME_ERROR, "Sorry, this time is not between 9:00 a.m. to 5:00 p.m. " +
                "Please enter an integer between 9 and 17 inclusive.");
        m.put(EventPrompts.INVALID_CAPACITY_ERROR,
                "Sorry, the capacity you entered is not an integer greater than 0.");
        m.put(EventPrompts.INPUT_NOT_INT_ERROR,
                "Sorry, the value you entered is not an integer.");
        m.put(EventPrompts.EVENT_CAPACITY_TOO_LARGE_ERROR,
                "Sorry, the requested room cannot support that many occupants.");
        m.put(EventPrompts.ROOM_IS_BOOKED, "This room is already booked at the given time.");
        m.put(EventPrompts.SPEAKER_SCHEDULE_DISPLAYED, "This is the schedule of events you are speaking at:");
        return m;
    }

    /**
     * Display all events to the user
     *
     * @param schedule list of all events
     */
    public void displaySchedule(List<String> schedule) {
        System.out.println("\n");
        System.out.println(String.join("\n", schedule));
    }

}
