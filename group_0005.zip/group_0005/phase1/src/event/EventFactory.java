package event;

import java.io.Serializable;

/**
 * This is a Factory class that calls the <code>Event</code> constructor. It is used to:
 * <ul>
 *     <li>Remove hard dependencies on <code>Event</code> from <code>EventManager</code></li>
 *     <li>Make <code>Event</code> more extensible when creating different types of Events</li>
 *     <li>Encapsulate the <code>Event</code> constructor calls</li>
 * </ul>
 *
 * @see Event
 */
class EventFactory implements Serializable {

    /**
     * Returns a new <code>Event</code> object with the specified title, start time, room ID, and occupant capacity.
     *
     * @param title     the name of the event
     * @param startTime an integer representing the hour in 24-hour clock format that the event starts at
     * @param roomID    the ID of the room in which the event is held
     * @param capacity  the maximum number of attendees that can be signed up for the event
     * @return a new <code>Event</code> object with the specified title, start time, room ID, and occupant capacity
     */
    public Event getEvent(String title, int startTime, int roomID, int capacity) {
        return new Event(title, startTime, roomID, capacity);
    }
}