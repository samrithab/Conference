package messaging;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * This class represents a message between users of the program.
 */
class Message implements Serializable {
    private final UUID messageId;
    private final String text;
    private final String author;
    private final List<String> recipients;
    private final List<UUID> replies;
    private final LocalDateTime timeSent;
    private final int nesting;

    /**
     * Creates a new message object using the given information.
     * Precondition: <code>recipients</code> must be nonempty.
     *
     * @param text       the text to be included in the message
     * @param author     the author of the message
     * @param recipients a nonempty list of usernames representing the recipients of this message
     * @param nesting    an integer that indicates how deeply nested this message is in the reply hierarchy.
     *                   More formally, this is 0 if this message is not a reply, or n + 1 if this is a reply to
     *                   a message with <code>nesting</code> equal to n.
     */
    public Message(String text, String author, List<String> recipients, int nesting) {
        this.messageId = UUID.randomUUID();
        this.text = text;
        this.author = author;
        this.recipients = recipients;
        this.replies = new ArrayList<>();
        this.timeSent = LocalDateTime.now();
        this.nesting = nesting;
    }

    /**
     * Gets the unique ID for this message, which is used to refer to this message.
     *
     * @return the ID for this message
     */
    public UUID getId() {
        return messageId;
    }

    /**
     * Gets the author for this message.
     *
     * @return the author for this message
     */
    public String getAuthor() {
        return author;
    }

    /**
     * Gets the nonempty list of usernames representing the recipients for this message.
     *
     * @return the nonempty list of recipient usernames
     */
    public List<String> getRecipients() {
        return recipients;
    }

    /**
     * Gets an integer that indicates how deeply nested this message is in the reply hierarchy.
     * More formally, this is 0 if this message is not a reply, or n + 1 if this is a reply to a message with
     * <code>nesting</code> equal to n.
     *
     * @return an integer that indicates how deeply nested this message is in the reply hierarchy
     */
    public int getNesting() {
        return nesting;
    }

    /**
     * Returns whether or not the user corresponding to username is a recipient of this message.
     *
     * @param username the username to check for being a recipient of this message
     * @return <code>true</code> if and only if this message has <code>username</code> as a recipient
     */
    public boolean hasRecipient(String username) {
        return recipients.contains(username);
    }

    /**
     * Gets the list of IDs corresponding to message that are replies to this message.
     *
     * @return the list of IDs corresponding to message that are replies to this message.
     */
    public List<UUID> getReplies() {
        return replies;
    }

    /**
     * Returns a string representation of this message. The string representation consists of the author of
     * this message, the list of recipients (separated by commas), and the text of this message.
     *
     * @return a string representation of this message
     */
    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM HH:mm");
        String formattedTime = timeSent.format(formatter);
        return String.format("%s\n%s said:\n> %s\n", formattedTime, author, text);
    }

    /**
     * Adds the ID for an existing message to the list of replies to this message.
     *
     * @param replyId the unique ID corresponding to a message to be added as a reply to this message
     */
    public void addReply(UUID replyId) {
        replies.add(replyId);
    }
}
