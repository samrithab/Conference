package messaging;

import system.ConsolePresenter;

import java.util.Collections;
import java.util.EnumMap;
import java.util.List;

/**
 * This class presents messaging information to the user and formats messages properly.
 */
class MessagePresenter extends ConsolePresenter<MessagePrompts> {


    /**
     * Returns an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     *
     * @return an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     */
    @Override
    protected EnumMap<MessagePrompts, String> initializeMessages() {
        EnumMap<MessagePrompts, String> m = new EnumMap<>(MessagePrompts.class);
        m.put(MessagePrompts.INBOX_TITLE, "Here is your inbox. Messages you can reply to are numbered.\n" +
                "==========================================================");
        m.put(MessagePrompts.END_OF_INBOX, "==========================================================\n" +
                "End of inbox.\n");
        m.put(MessagePrompts.RECIPIENTS_INPUT_PROMPT, "Please enter the recipients' usernames (separated by commas) " +
                "and then hit Enter.");
        m.put(MessagePrompts.SINGLE_RECIPIENT_INPUT_PROMPT, "Please enter a recipient and then hit Enter.");
        m.put(MessagePrompts.TEXT_INPUT_PROMPT, "Please enter the text for your message.");
        m.put(MessagePrompts.MESSAGE_CONFIRMATION, "Your message has been sent to all valid recipients:");
        m.put(MessagePrompts.REPLY_CONFIRMATION, "Your reply has been sent.");
        m.put(MessagePrompts.MESSAGE_SELECTION_PROMPT, "Please enter the number of the message you wish to reply to.");
        m.put(MessagePrompts.MESSAGE_SELECTION_CANCELLED, "Cancelled message selection.");
        m.put(MessagePrompts.EMPTY_INBOX_ERROR, "Sorry, you do not have any messages in your inbox.");
        m.put(MessagePrompts.NO_RECIPIENTS_ERROR, "Sorry, there were no valid recipients.");
        m.put(MessagePrompts.INVALID_MESSAGE_SELECTION_ERROR, "Sorry, that is not a valid message number.");
        return m;
    }

    /**
     * Displays a message with the given information to the user.
     * <ul>
     *     <li>The message will be indented according to its nesting level in the reply hierarchy.</li>
     *     <li>If the user should be able to reply to this message, the message will be numbered,
     *     with number <code>curNum</code>.</li>
     * </ul>
     *
     * @param message  the message (as a string) to display to the user
     * @param nesting  the nesting level of this message in the reply hierarchy
     * @param canReply whether or not the user should be able to reply to this message
     * @param curNum   the current message number, to be displayed alongside the message if and only if
     *                 <code>canReply</code> is true
     */
    public void displayMessage(String message, int nesting, boolean canReply, int curNum) {
        String formattedMessage = indentString(message, nesting);
        if (canReply) {
            System.out.printf("%d: %s%n", curNum, formattedMessage);
        } else {
            System.out.printf("%s%n", formattedMessage);
        }
    }

    /**
     * Indents a string to a specified indent level.
     *
     * @param toIndent    the string to be indented
     * @param indentLevel the indent level to be applied
     * @return <code>toIndent</code>, indented <code>indentLevel</code> times
     */
    private String indentString(String toIndent, int indentLevel) {
        String indent = String.join("", Collections.nCopies(indentLevel, "\t"));
        // Match the start of every line. ?m indicates multiline mode - all lines will be matched.
        return toIndent.replaceAll("(?m)^", indent);
    }

    /**
     * Displays that a message was sent, along with the names of the valid recipients to which the message was sent.
     *
     * @param recipients the usernames of the recipients to which the message was sent
     */
    public void displayMessageConfirmation(List<String> recipients) {
        display(MessagePrompts.MESSAGE_CONFIRMATION);
        System.out.println(String.join(", ", recipients));
    }

}
