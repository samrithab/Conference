package messaging;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * This class stores and manipulates <code>Message</code> objects in the program.
 */
public class MessageManager implements Serializable {
    /**
     * Representation invariant: the <code>Message</code> objects stored in <code>messages</code> are stored in
     * the order in which they were added to the list.
     */
    private final List<Message> messages;
    private final MessageFactory factory;

    /**
     * Creates a new <code>MessageManager</code> object from the given list of <code>Message</code> objects.
     *
     * @param messages a list of messages to initialize the manager with
     */
    public MessageManager(List<Message> messages) {
        this.messages = messages;
        this.factory = new MessageFactory();
    }

    /**
     * Creates a new <code>MessageManager</code> object with no messages.
     */
    public MessageManager() {
        this(new ArrayList<>());
    }

    /**
     * Gets the <code>Message</code> object corresponding to the ID <code>messageId</code>.
     * <p></p>
     * Precondition: a <code>Message</code> with ID <code>messageId</code> should already exist.
     *
     * @param messageId the ID for the <code>Message</code> object to retrieve
     * @return the unique <code>Message</code> object with ID <code>messageId</code>
     * @throws MessageNotFoundException if a <code>Message</code> with ID <code>messageId</code> does not exist.
     */
    private Message getMessageWithId(UUID messageId) {
        for (Message message : messages) {
            if (message.getId() == messageId) {
                return message;
            }
        }
        throw new MessageNotFoundException(String.format("Message with ID %s does not exist.", messageId.toString()));
    }

    //<editor-fold desc="Adding Messages and Replies">

    /**
     * Add a new message to the list of messages.
     * <p></p>
     * Precondition: <code>recipients</code> is not empty.
     *
     * @param text       the text for the message
     * @param author     the author for the message
     * @param recipients a nonempty list of recipient usernames for the message
     * @param nesting    an integer that indicates how deeply nested this message is in the reply hierarchy.
     *                   More formally, this is 0 if this message is not a reply, or n + 1 if this is a reply to
     *                   a message with nesting level equal to n.
     */
    public void addMessage(String text, String author, List<String> recipients, int nesting) {
        messages.add(factory.getMessage(text, author, recipients, nesting));
    }

    /**
     * Adds a reply with a given text and author to a message with ID <code>messageId</code>.
     * <p></p>
     * Precondition: a <code>Message</code> with ID <code>messageId</code> should already exist.
     *
     * @param text      the text for the reply
     * @param author    the author for the reply
     * @param messageId the ID for the message that is being replied to
     */
    public void replyToMessage(String text, String author, UUID messageId) {
        Message message = getMessageWithId(messageId);
        String originalAuthor = message.getAuthor();
        List<String> replyRecipient = Collections.singletonList(originalAuthor);
        Message reply = factory.getMessage(text, author, replyRecipient, message.getNesting() + 1);
        messages.add(reply);
        message.addReply(reply.getId());
    }
    //</editor-fold>

    //<editor-fold desc="Getting Lists of Message IDs">

    /**
     * Returns a list of IDs corresponding to replies of the message whose ID is <code>messageId</code>.
     * <p></p>
     * The list of reply IDs is ordered according to when these replies were added to the manager;
     * earlier replies appear earlier in the list.
     * <p></p>
     * Precondition: a <code>Message</code> with ID <code>messageId</code> should already exist.
     *
     * @param messageId the ID corresponding to the message whose replies are returned
     * @return a list of IDs corresponding to replies of the message whose ID is <code>messageId</code>
     */
    public List<UUID> getReplies(UUID messageId) {
        Message message = getMessageWithId(messageId);
        return message.getReplies();
    }

    /**
     * Returns a list of IDs corresponding to messages that pertain to user <code>username</code>. More precisely,
     * the IDs returned are those of all messages with <code>username</code> as an author or a recipient.
     * <p></p>
     * The list of IDs is ordered according to when the corresponding messages were added to the manager;
     * earlier messages appear earlier in the list.
     *
     * @param username the user whose incoming and outgoing messages are returned
     * @return a list of IDs of all messages with <code>username</code> as an author or a recipient
     */
    public List<UUID> getMessagesToOrFromUser(String username) {
        List<UUID> messagesToOrFromUser = new ArrayList<>();
        for (Message message : messages) {
            if (message.getRecipients().contains(username) || message.getAuthor().equals(username)) {
                messagesToOrFromUser.add(message.getId());
            }
        }
        return messagesToOrFromUser;
    }
    //</editor-fold>

    //<editor-fold desc="Getting Information about a User's Messages">

    /**
     * Returns whether or not the message with ID <code>messageId</code> has <code>username</code> as a recipient.
     * <p></p>
     * Precondition: a <code>Message</code> with ID <code>messageId</code> should already exist.
     *
     * @param username  username to search for among the recipients of the message
     * @param messageId the ID of the message whose recipients are checked
     * @return <code>true</code> if and only if the message with ID <code>messageId</code> has <code>username</code>
     * as a recipient.
     */
    public boolean isRecipient(String username, UUID messageId) {
        Message message = getMessageWithId(messageId);
        return message.hasRecipient(username);
    }

    /**
     * Returns whether or not the user <code>username</code> is the recipient of any of the existing messages.
     *
     * @param recipient the user for which the existence of incoming messages is checked
     * @return <code>true</code> if and only if one or more messages with <code>username</code> as a recipient exist
     */
    public boolean messagesToUserExist(String recipient) {
        for (Message message : messages) {
            if (message.getRecipients().contains(recipient)) {
                return true;
            }
        }
        return false;
    }
    //</editor-fold>

    //<editor-fold desc="Getting Information about Specific Messages">

    /**
     * Returns a string representation of the message with ID <code>messageId</code>.
     * <p></p>
     * Precondition: a <code>Message</code> with ID <code>messageId</code> should already exist.
     *
     * @param messageId the ID of the message whose string representation is returned
     * @return a string representation of the message with ID <code>messageId</code>
     */
    public String getMessageAsString(UUID messageId) {
        Message message = getMessageWithId(messageId);
        return message.toString();
    }

    /**
     * Returns whether or not the message with ID <code>messageId</code> has at least one reply.
     * <p></p>
     * Precondition: a <code>Message</code> with ID <code>messageId</code> should already exist.
     *
     * @param messageId the ID for the message whose list of replies is checked
     * @return <code>true</code> if and only if the message with ID <code>messageId</code> has at least one reply.
     */
    public boolean hasReplies(UUID messageId) {
        return !getMessageWithId(messageId).getReplies().isEmpty();
    }

    /**
     * Returns an integer that indicates how deeply nested this message is in the reply hierarchy.
     * More formally, this is 0 if this message is not a reply, or n + 1 if this message is a reply to a message with
     * nesting level equal to n.
     * <p></p>
     * Precondition: a <code>Message</code> with ID <code>messageId</code> should already exist.
     *
     * @param messageId the ID for the message whose nesting level is returned
     * @return an integer that indicates how deeply nested this message is in the reply hierarchy.
     */
    public int getNestingLevel(UUID messageId) {
        return getMessageWithId(messageId).getNesting();
    }
    //</editor-fold>
}
