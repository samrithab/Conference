package messaging;

/**
 * This enum contains keys specifying the one-line text prompts
 * that can be printed to console during interactions in <code>MessageController</code>.
 */
enum MessagePrompts {

    INBOX_TITLE,
    END_OF_INBOX,
    RECIPIENTS_INPUT_PROMPT,
    SINGLE_RECIPIENT_INPUT_PROMPT,
    TEXT_INPUT_PROMPT,
    MESSAGE_CONFIRMATION,
    REPLY_CONFIRMATION,
    MESSAGE_SELECTION_PROMPT,
    MESSAGE_SELECTION_CANCELLED,
    EMPTY_INBOX_ERROR,
    NO_RECIPIENTS_ERROR,
    INVALID_MESSAGE_SELECTION_ERROR;


}
