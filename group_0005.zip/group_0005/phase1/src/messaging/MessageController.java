package messaging;

import java.util.*;

/**
 * This class allows the user to interact with the messaging system in the program.
 */
public class MessageController {
    private final MessageManager manager;
    private final MessagePresenter presenter;
    private final Scanner in;

    /**
     * Creates a new <code>MessageController</code> object.
     *
     * @param in      a scanner used by this controller to get user input
     * @param manager a <code>MessageManager</code> used by this controller to interact with messages
     */
    public MessageController(Scanner in, MessageManager manager) {
        this.manager = manager;
        this.presenter = new MessagePresenter();
        this.in = in;
    }


    //<editor-fold desc="Replies">

    /**
     * Returns an ID corresponding to a message that the user has selected, if the selection was valid.
     * The message must have <code>username</code> as a recipient.
     * <p>
     * Precondition: there is at least one message sent to the user <code>username</code>.
     *
     * @param username the username whose message inbox is being used
     * @return the UUID of the message selected (wrapped in an <code>Optional</code>), if the selection was successful;
     * <code>Optional.empty()</code> otherwise
     */
    private Optional<UUID> readMessageSelection(String username) {
        List<UUID> inbox = getAllMessagesToUserInConversationOrder(username);
        presenter.display(MessagePrompts.MESSAGE_SELECTION_PROMPT);
        OptionalInt selection = validateMessageSelection(inbox.size());
        if (selection.isPresent()) {
            return Optional.of(inbox.get(selection.getAsInt() - 1));
        }
        return Optional.empty();
    }

    /**
     * Returns a number that the user has entered to select a message in their inbox, if the selection was successful.
     * A valid selection is an integer <code>n</code> such that <code>1 <= n <= numMessages</code>.
     *
     * @param numMessages the number of messages that the user can select between
     * @return an integer between 1 and <code>numMessages</code> inclusive (wrapped in an <code>OptionalInt</code>) if
     * the selection was successful; <code>OptionalInt.empty()</code> otherwise
     */
    private OptionalInt validateMessageSelection(int numMessages) {
        if (!in.hasNextInt()) {
            in.nextLine();
            presenter.display(MessagePrompts.INVALID_MESSAGE_SELECTION_ERROR);
            return OptionalInt.empty();
        } else {
            return validateMessageSelectionInteger(numMessages);
        }
    }

    /**
     * Returns a number that the user has entered to select a message in their inbox, if the selection was successful.
     * valid selection is an integer <code>n</code> such that <code>1 <= n <= numMessages</code>.
     * <p></p>
     * Precondition: the next input to be read from the console is an integer.
     *
     * @param numMessages the number of messages that the user can select between
     * @return an integer between 1 and <code>numMessages</code> inclusive (wrapped in an <code>OptionalInt</code>) if
     * the selection was successful; <code>OptionalInt.empty()</code> otherwise
     */
    private OptionalInt validateMessageSelectionInteger(int numMessages) {
        int selection = in.nextInt();
        in.nextLine();
        if (selection >= 1 && selection <= numMessages) {
            return OptionalInt.of(selection);
        }
        return OptionalInt.empty();
    }

    /**
     * Replies to a message sent to the user <code>author</code>. Displays the user's inbox and allows the user to
     * select a message to reply to before entering the content of the reply.
     *
     * @param author the username of the reply's author
     */
    public void replyToMessage(String author) {
        viewInbox(author);
        if (manager.messagesToUserExist(author)) {
            Optional<UUID> toReply = readMessageSelection(author);
            if (toReply.isPresent()) {
                processReply(toReply.get(), author);
            } else {
                presenter.display(MessagePrompts.MESSAGE_SELECTION_CANCELLED);
            }
        }
    }

    /**
     * Processes a reply to the message whose ID is <code>toReply</code>.
     * <p></p>
     * Preconditions:
     * <ul>
     *     <li>A message whose ID is <code>toReply</code> must already exist.</li>
     *     <li><code>author</code> must be in the list of recipients of the message <code>toReply</code>.</li>
     * </ul>
     *
     * @param toReply the ID of the message being replied to
     * @param author  the author of the reply
     */
    private void processReply(UUID toReply, String author) {
        String text = readText();
        manager.replyToMessage(text, author, toReply);
        presenter.display(MessagePrompts.REPLY_CONFIRMATION);
    }
    //</editor-fold>

    //<editor-fold desc="Sending Messages">

    /**
     * Prompts the user to enter text for the message to be sent. The message is authored by <code>author</code>
     * and is sent to <code>recipients</code>, if this list is nonempty. Otherwise an error message is displayed.
     *
     * @param author     the author of the message
     * @param recipients the list of recipients to whom the message will be sent
     */
    public void sendMessage(String author, List<String> recipients) {
        if (recipients.isEmpty()) {
            presenter.display(MessagePrompts.NO_RECIPIENTS_ERROR);
        } else {
            String text = readText();
            manager.addMessage(text, author, recipients, 0);
            presenter.displayMessageConfirmation(recipients);
        }
    }

    /**
     * Prompts and reads the text for a message to be sent by the user.
     *
     * @return the text entered by the user (all on one line)
     */
    private String readText() {
        presenter.display(MessagePrompts.TEXT_INPUT_PROMPT);
        return in.nextLine();
    }

    /**
     * Prompts the user to enter a comma-separated list of recipients for a message, and returns a list of the
     * recipient usernames entered. These usernames need not represent existing users in the system.
     *
     * @return a list of recipient usernames entered by the user
     */
    public List<String> readRecipients() {
        presenter.display(MessagePrompts.RECIPIENTS_INPUT_PROMPT);
        String recipientInput = in.nextLine();
        // Split the string at points where the regex matches: 0 or more whitespaces, a comma, and 0 or more whitespaces
        return Arrays.asList(recipientInput.split("\\s*,\\s*"));
    }

    /**
     * Prompts the user to enter a single recipient for a message, and returns the user's input.
     *
     * @return a recipient's name that the user has entered
     */
    public String readSingleRecipient() {
        presenter.display(MessagePrompts.SINGLE_RECIPIENT_INPUT_PROMPT);
        return in.nextLine();
    }
    //</editor-fold>

    //<editor-fold desc="Displaying the Inbox">

    /**
     * Displays the inbox for the user <code>username</code>.
     * <p></p>
     * This inbox consists of all messages sent to or by
     * the user <code>username</code> (or replies to such messages), where the user's conversations
     * (threads of parent messages and all arbitrarily-nested replies) are ordered by the time when the parent messages
     * were added to the system, from oldest to newest. If the user has no conversations, an appropriate message is displayed.
     *
     * @param username the name of the user whose inbox is displayed
     */
    public void viewInbox(String username) {
        if (userHasConversations(username)) {
            presenter.display(MessagePrompts.INBOX_TITLE);
            displayAllUserConversations(username);
            presenter.display(MessagePrompts.END_OF_INBOX);
        } else {
            presenter.display(MessagePrompts.EMPTY_INBOX_ERROR);
        }
    }

    /**
     * Displays all the conversations in the inbox for the user <code>username</code>.
     * <p></p>
     * The conversations are ordered by the time when the parent messages were added to the system, from oldest to
     * newest. This ordering applies at every level of the reply hierarchy, i.e. sub-conversations of a conversation
     * are also ordered as above. Messages are nested according to their nesting level in the reply hierarchy.
     * Messages that the user <code>username</code> can reply to are numbered in the order that they appear to the user.
     *
     * @param username the name of the user whose inbox is displayed
     */
    private void displayAllUserConversations(String username) {
        List<UUID> allMessages = getAllConversationsInOrder(username);
        int curNum = 1;
        for (UUID messageId : allMessages) {
            String messageString = manager.getMessageAsString(messageId);
            int nesting = manager.getNestingLevel(messageId);
            boolean canReply = manager.isRecipient(username, messageId);
            presenter.displayMessage(messageString, nesting, canReply, curNum);
            if (canReply) {
                curNum++;
            }
        }
    }

    /**
     * Gets all the IDs of messages that user <code>username</code> can reply to. The messages appear in the the list
     * in the order that they that they appear to the user, as specified in the
     * {@link #displayAllUserConversations(String) displayAllUserConversations} method.
     *
     * @param username the name of the user whom the messages returned all have as a recipient
     * @return a list of IDs of messages that user <code>username</code>  can reply to.
     */
    private List<UUID> getAllMessagesToUserInConversationOrder(String username) {
        List<UUID> allMessages = getAllConversationsInOrder(username);
        List<UUID> messagesToUser = new ArrayList<>();
        for (UUID messageId : allMessages) {
            if (manager.isRecipient(username, messageId)) {
                messagesToUser.add(messageId);
            }
        }
        return messagesToUser;
    }

    /**
     * Returns a list of IDs of all the messages in the conversations of the user <code>username</code>. That is, the
     * IDs represent messages sent to or by <code>username</code>, or replies to such messages. The messages appear in
     * the list in the order that they appear to the user, as specified in the
     * {@link #displayAllUserConversations(String) displayAllUserConversations} method.
     *
     * @param username the name of the user whose conversation messages are returned
     * @return a list of IDs of all the messages in the conversations of the user <code>username</code>
     */
    private List<UUID> getAllConversationsInOrder(String username) {
        List<UUID> messageIds = manager.getMessagesToOrFromUser(username);
        List<UUID> allMessages = new ArrayList<>();
        for (UUID messageId : messageIds) {
            if (manager.getNestingLevel(messageId) == 0) {
                allMessages.addAll(getDisplayedConversationOrder(messageId));
            }
        }
        return allMessages;
    }

    /**
     * Returns a list of IDs of all the messages in the conversation whose parent message has ID <code>parentId</code>.
     * <code>parentId</code> itself will also be among the IDs returned.
     *
     * @param parentId the ID of the message at the top of the thread
     * @return a list of IDs of all the messages in the conversation whose parent message has ID <code>parentId</code>
     */
    private List<UUID> getDisplayedConversationOrder(UUID parentId) {
        List<UUID> conversationMessages = new ArrayList<>();
        conversationMessages.add(parentId);
        List<UUID> replies = manager.getReplies(parentId);
        for (UUID reply : replies) {
            conversationMessages.addAll(getDisplayedConversationOrder(reply));
        }
        return conversationMessages;
    }

    /**
     * Returns whether or not the user <code>username</code> has participated in any conversations. That is,
     * whether or not there are any messages sent to or by the user.
     *
     * @param username the user for whom existence of conversations is checked
     * @return <code>true</code> if and only if there are messages having <code>username</code> as author or recipient
     */
    private boolean userHasConversations(String username) {
        return !manager.getMessagesToOrFromUser(username).isEmpty();
    }
    //</editor-fold>
}
