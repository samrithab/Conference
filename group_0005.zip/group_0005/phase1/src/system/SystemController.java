package system;

import event.EventController;
import messaging.MessageController;
import room.RoomController;
import signup.SignUpController;
import user.UserController;

import java.util.List;
import java.util.Scanner;

/**
 * The SystemController class defines the common actions that all users can do.
 * This class determines which menu options the user sees once they log in and directs the requests to complete those
 * actions.
 */
public class SystemController {
    protected final EventController eventController;
    protected final UserController userController;
    protected final MessageController messageController;
    protected final RoomController roomController;
    protected final SystemPresenter presenter;
    protected final Scanner in;
    protected final String curUser;
    protected final SignUpController signUpController;

    /**
     * Constructs a controller to process the user's requests given a menu of options.
     *
     * @param presenter a <code>SystemPresenter</code> object that enables the display of messages related to the menu
     * @param managers  the managers responsible for data during program execution
     * @param curUser   the username of the currently logged in user
     * @param in        the instance of Scanner currently looking at the Console
     */
    public SystemController(SystemPresenter presenter,
                            ManagerParameterObject managers, String curUser, Scanner in) {
        this.eventController = new EventController(managers.getEventManager(), managers.getRoomManager(), in);
        this.userController = new UserController(managers.getUserManager(), in);
        this.roomController = new RoomController(managers.getRoomManager(), in);
        this.messageController = new MessageController(in, managers.getMessageManager());
        this.presenter = presenter;
        this.curUser = curUser;
        this.in = in;
        this.signUpController = new SignUpController(in, managers.getEventManager());
    }

    /**
     * Reads in and processes a user's request to complete an action until they choose to log out.
     */
    public void run() {
        boolean quit = false;
        int input;
        while (!quit) {
            presenter.displayMenuOptions();
            if (!in.hasNextInt()) {        /* input must be an integer */
                presenter.displayInvalidInputError();
                presenter.promptForAction();
                in.nextLine();
            } else {
                input = in.nextInt();
                in.nextLine();
                quit = processInput(input);
            }
        }
    }

    /**
     * Determines which menu of options the user input corresponds to.
     *
     * @param input the user input corresponding to a numbered action in a menu of options
     * @return true if the user requests to log out of the program
     */
    protected boolean processInput(int input) {
        return processDefaultMenu(input);
    }

    /**
     * Processes user input that corresponds to a request for one of the common actions that all users can do.
     *
     * @param input the user input corresponding to a numbered action in a menu of options
     * @return true if the user requests to log out of the program
     */
    protected boolean processDefaultMenu(int input) {
        boolean quit = false;
        switch (input) {
            case 1:
                quit = true;
                break;
            case 2:
                eventController.displayCompleteSchedule();
                break;
            case 3:
                signUpController.searchForEvents();
                break;
            case 4:
                signUpController.signUpForEvent(curUser);
                break;
            case 5:
                signUpController.cancelSpotInEvent(curUser);
                break;
            case 6:
                eventController.displayUserSchedule(curUser);
                break;
            case 7:
                userController.manageFriendsList(curUser);
                break;
            case 8:
                messageController.viewInbox(curUser);
                break;
            case 9:
                messageController.replyToMessage(curUser);
                break;
            case 10:
                messageFriend();
                break;
            default:
                presenter.displayInvalidInputError();
        }
        return quit;
    }

    private void messageFriend() {
        userController.viewFriendsList(curUser);
        if (userController.userHasFriends(curUser)) {
            List<String> recipients = messageController.readRecipients();
            recipients = userController.filterForExistingUsernames(recipients);
            recipients = userController.filterForFriendsUsernames(recipients, curUser);
            messageController.sendMessage(curUser, recipients);
        }
    }

}
