package system;

import java.util.List;
import java.util.Scanner;

/**
 * The <code>SpeakerSystemController</code> class defines the specialized actions that a Speaker can do.
 * This class determines which additional menu options a Speaker sees once they log in and directs the requests
 * to complete those actions. Such actions are generally related to the events that a Speaker is speaking at in the
 * conference.
 */
class SpeakerSystemController extends SystemController {

    /**
     * Constructs a <code>SpeakerSystemController</code> object to process the speaker's requests.
     *
     * @param presenter a <code>SystemPresenter</code> object that enables the display of messages related to the menu
     * @param managers  the managers responsible for data during program execution
     * @param curUser   the username of the currently logged in user
     * @param in        the instance of Scanner currently looking at the Console
     */
    public SpeakerSystemController(SystemPresenter presenter,
                                   ManagerParameterObject managers, String curUser, Scanner in) {
        super(presenter, managers, curUser, in);
    }


    /**
     * Determines which menu of options the user input corresponds to.
     *
     * @param input the user input corresponding to a numbered action in a menu of options
     * @return <code>true</code> if and only if the user requests to log out of the program
     */
    @Override
    protected boolean processInput(int input) {
        if (input >= 1 && input <= 10) {
            return processDefaultMenu(input);
        } else {
            processSpeakerMenu(input);
            return false;
        }
    }

    /**
     * Processes user input that corresponds to a request for one of the actions that only Speakers can do.
     *
     * @param input the user input corresponding to a numbered action in a menu of options
     */
    private void processSpeakerMenu(int input) {
        switch (input) {
            case 11:
                eventController.displaySpeakerEvents(curUser);
                break;
            case 12:
                messageAllYourEventAttendees();
                break;
            case 13:
                messageAttendeesForOneEvent();
                break;
            default:
                presenter.displayInvalidInputError();
        }
    }

    /**
     * Messages all attendees of the events at which the current user is speaking.
     */
    private void messageAllYourEventAttendees() {
        List<String> recipients = eventController.getAttendeesForEventsBySpeaker(curUser);
        messageController.sendMessage(curUser, recipients);
    }

    /**
     * Messages all attendees of a single event at which the current user is speaking.
     */
    private void messageAttendeesForOneEvent() {
        String title = eventController.readEventTitle();
        if (eventController.isSpeakerForEvent(curUser, title)) {
            List<String> recipients = eventController.getAttendeesForEvent(title);
            messageController.sendMessage(curUser, recipients);
        }
    }
}
