package system;

/**
 * The <code>OrganizerSystemPresenter</code> class is responsible for displaying menu options specific to an Organizer.
 * This responsibility implies that the class currently acts as a Presenter and a UI.
 */
class OrganizerSystemPresenter extends SystemPresenter {
    /**
     * Displays the menu options for all user actions and additionally the organizer actions.
     */
    @Override
    public void displayMenuOptions() {
        super.displayMenuOptions();
        System.out.println("===== ORGANIZER ACTIONS =====");
        System.out.println("11 - Add a new event to the conference");
        System.out.println("12 - Enter a new room into the system");
        System.out.println("13 - Create a new account for a speaker");
        System.out.println("14 - Assign a speaker to an event");
        System.out.println("15 - View all rooms");
        System.out.println("16 - View all attendees");
        System.out.println("17 - View all speakers");
        System.out.println("18 - Message all attendees");
        System.out.println("19 - Message all speakers");
        System.out.println("20 - Message a specific attendee");
        System.out.println("21 - Message a specific speaker");
    }

}