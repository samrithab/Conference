package system;

/**
 * The <code>OrganizerSystemPresenter</code> class is responsible for displaying menu options specific to an Speaker.
 * This responsibility implies that the class currently acts as a Presenter and a UI.
 */
class SpeakerSystemPresenter extends SystemPresenter {

    /**
     * Displays the menu options for all user actions and additionally the speaker actions.
     */
    @Override
    public void displayMenuOptions() {
        super.displayMenuOptions();
        System.out.println("===== SPEAKER ACTIONS =====");
        System.out.println("11 - See the list of talks you are speaking at");
        System.out.println("12 - Message all attendees of all your talks");
        System.out.println("13 - Message all attendees of one of your talks");
    }

}
