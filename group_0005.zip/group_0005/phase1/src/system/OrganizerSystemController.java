package system;

import startup.AccountCreationController;
import user.UserType;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * The <code>OrganizerSystemController</code> class defines the specialized actions that an Organizer can do.
 * This class determines which additional menu options an Organizer sees once they log in and directs the requests
 * to complete those actions. These actions are generally related to input of new data into the program
 * and advanced capabilities for common actions such as viewing information and messaging.
 */
class OrganizerSystemController extends SystemController {

    private final AccountCreationController accountCreationController;

    /**
     * Constructs a <code>OrganizerSystemController</code> object to process the organizer's requests.
     *
     * @param presenter a <code>SystemPresenter</code> object that enables the display of messages related to the menu
     * @param managers  the managers responsible for data during program execution
     * @param curUser   the username of the currently logged in user
     * @param in        the instance of Scanner currently looking at the Console
     */
    public OrganizerSystemController(SystemPresenter presenter,
                                     ManagerParameterObject managers, String curUser, Scanner in) {
        super(presenter, managers, curUser, in);
        this.accountCreationController = new AccountCreationController(managers.getUserManager(), in);
    }

    /**
     * Determines which menu of options the user input corresponds to.
     *
     * @param input the user input corresponding to a numbered action in a menu of options
     * @return <code>true</code> if and only if the user requests to log out of the program
     */
    @Override
    protected boolean processInput(int input) {
        if (input >= 1 && input <= 10) {
            return processDefaultMenu(input);
        } else {
            processOrganizerMenu(input);
            return false;
        }
    }

    /**
     * Processes user input that corresponds to a request for one of the actions that only Organizers can do.
     *
     * @param input the user input corresponding to a numbered action in a menu of options
     */
    private void processOrganizerMenu(int input) {
        switch (input) {
            case 11:
                eventController.addNewEvent();
                break;
            case 12:
                roomController.enterNewRoom();
                break;
            case 13:
                accountCreationController.createSpeakerAccount();
                break;
            case 14:
                scheduleSpeakerToEvent();
                break;
            case 15:
                roomController.viewRooms();
                break;
            case 16:
                userController.viewUsernamesOfType(UserType.ATTENDEE);
                break;
            case 17:
                userController.viewUsernamesOfType(UserType.SPEAKER);
                break;
            case 18:
                messageAllUsersOfType(UserType.ATTENDEE);
                break;
            case 19:
                messageAllUsersOfType(UserType.SPEAKER);
                break;
            case 20:
                messageUserOfType(UserType.ATTENDEE);
                break;
            case 21:
                messageUserOfType(UserType.SPEAKER);
                break;
            default:
                presenter.displayInvalidInputError();
        }
    }

    /**
     * Messages a specific user of type <code>userType</code>.
     *
     * @param userType the type of user that can be messaged
     */
    private void messageUserOfType(UserType userType) {
        userController.viewUsernamesOfType(userType);
        String recipient = messageController.readSingleRecipient();
        List<String> validRecipients = new ArrayList<>();
        if (userController.isUserOfType(recipient, userType)) {
            validRecipients.add(recipient);
        }
        messageController.sendMessage(curUser, validRecipients);
    }

    /**
     * Messages all users of type <code>userType</code>.
     *
     * @param userType the type of user to message
     */
    private void messageAllUsersOfType(UserType userType) {
        List<String> recipients = userController.getAllUsernamesOfType(userType);
        messageController.sendMessage(curUser, recipients);
    }

    /**
     * Schedules a speaker to an existing event.
     */
    private void scheduleSpeakerToEvent() {
        String speaker = eventController.readSpeaker();
        boolean isSpeaker = userController.isUserOfType(speaker, UserType.SPEAKER);
        eventController.scheduleSpeakerToEvent(speaker, isSpeaker);
    }

}
