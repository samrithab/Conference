package system;

/**
 * The <code>SystemPresenter</code> class is responsible for displaying the default menu options that any type of
 * user can access. This responsibility implies that the class currently acts as a Presenter and a UI.
 */
class SystemPresenter {
    /**
     * Prints message to get user input for an action.
     */
    public void promptForAction() {
        System.out.println("Please select an action.");
    }

    /**
     * Displays all menu options for actions that a user can choose from.
     */
    public void displayMenuOptions() {
        System.out.println("===== SYSTEM =====");
        System.out.println("1 - Log out");
        System.out.println("===== EVENTS =====");
        System.out.println("2 - View all events scheduled in the conference");
        System.out.println("3 - Filter the events by title, speaker, or start time");
        System.out.println("4 - Sign up for an event");
        System.out.println("5 - Cancel your spot in an event");
        System.out.println("6 - View your event schedule");
        System.out.println("===== MESSAGING =====");
        System.out.println("7 - Manage your friends list");
        System.out.println("8 - View your inbox");
        System.out.println("9 - Reply to a message");
        System.out.println("10 - Message a friend");
    }

    /**
     * Displays message if the user input is invalid.
     */
    public void displayInvalidInputError() {
        System.out.println("Sorry, the input you entered was not valid. Please try again.");
    }

}
