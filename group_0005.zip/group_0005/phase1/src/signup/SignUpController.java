package signup;

import event.EventManager;
import event.EventNotFoundException;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


/**
 * The SignUpController class is responsible for a user's registration and cancelling registration for
 * various events. This class also allows a user to be able to filter an Event by it's Title, Speaker, or Start Time
 */
public class SignUpController {
    private final EventManager eventManager;
    private final SignUpPresenter signUpPresenter;
    private final Scanner in;

    /**
     * Creates a new <code>SignUpController</code> object.
     *
     * @param in           a Scanner used by this controller to get user input
     * @param eventManager an <code>EventManager</code> that is used by this class to interact with events
     */
    public SignUpController(Scanner in, EventManager eventManager) {
        this.eventManager = eventManager;
        this.signUpPresenter = new SignUpPresenter();
        this.in = in;
    }

    /**
     * Searches for <code>Events</code> by either the Title, Speaker, or StartTime of an <code>event</code>.
     * Prompts the user to choose a specified parameter to search by, and displays an error message if the input
     * is invalid.
     */
    public void searchForEvents() {
        String eventParameter;
        boolean quit = false;
        while (!quit) {
            signUpPresenter.display(SignUpPrompts.CHOOSE_FILTER);
            eventParameter = in.nextLine();
            switch (eventParameter) {
                case "1":
                    searchByTitleOrSpeaker(SignUpPrompts.ENTER_TITLE_PROMPT);
                    quit = true;
                    break;
                case "2":
                    searchByTitleOrSpeaker(SignUpPrompts.ENTER_SPEAKER_PROMPT);
                    quit = true;
                    break;
                case "3":
                    searchByTime();
                    quit = true;
                    break;
                case "4":
                    quit = true;
                    break;
                default:
                    signUpPresenter.display(SignUpPrompts.INVALID_INPUT);
            }
        }
    }

    /**
     * Displays a list of <code>events</code> that contain the given title or speaker, or gives an error message if
     * no <code>events</code> have the specified title or speaker.
     *
     * @param message The message prompt to be displayed before taking in an input
     */
    private void searchByTitleOrSpeaker(SignUpPrompts message) {
        signUpPresenter.display(message);
        List<String> tempEventList = new ArrayList<>();
        String eventParameter = in.nextLine();
        for (String tempEventTitle : eventManager.getEventList()) {
            if (eventParameter.equals(tempEventTitle) ||
                    eventParameter.equals(eventManager.getSpeaker(tempEventTitle))) {
                tempEventList.add(tempEventTitle);
            }
        }
        if (tempEventList.isEmpty()) {
            signUpPresenter.display(SignUpPrompts.EVENT_NOT_FOUND_ERROR);
        } else {
            signUpPresenter.showFilteredEvents(eventManager.getStringRepresentations(tempEventList));
        }
    }

    /**
     * Displays a list  of <code>events</code>that contain the specified start time, or an error message if no
     * <code>events</code> have the specified start time. If the input is not an <code>int</code>, repeats until a
     * valid input is given.
     */
    private void searchByTime() {
        boolean quit = false;
        int input = 0;
        List<String> tempEventList = new ArrayList<>();
        while (!quit) {
            signUpPresenter.display(SignUpPrompts.ENTER_TIME_PROMPT);
            if (!in.hasNextInt()) {
                signUpPresenter.display(SignUpPrompts.INVALID_TIME);
                in.nextLine();
            } else {
                input = in.nextInt();
                in.nextLine();
                quit = true;
            }
        }
        for (String tempEventTitle : eventManager.getEventList()) {
            if (input == eventManager.getStartTime(tempEventTitle)) {
                tempEventList.add(tempEventTitle);
            }
        }
        if (tempEventList.isEmpty()) {
            signUpPresenter.display(SignUpPrompts.EVENT_NOT_FOUND_ERROR);
        } else {
            signUpPresenter.showFilteredEvents(eventManager.getStringRepresentations(tempEventList));
        }
    }

    /**
     * Processes a user's request to sign up for an event.
     *
     * @param username The username of the currently logged in user
     */
    public void signUpForEvent(String username) {
        signUpPresenter.display(SignUpPrompts.SIGNUP_PROMPT);
        String title = in.nextLine();
        try {
            if (eventManager.getEventsByUser(username).contains(title)) {
                signUpPresenter.display(SignUpPrompts.ALREADY_SIGNED_UP);
                return;
            } else if (eventManager.getSpeaker(title) != null && eventManager.getSpeaker(title).equals(username)) {
                signUpPresenter.display(SignUpPrompts.SPEAKER_SIGN_UP_ERROR);
                return;
            }
            boolean successfulSignup = eventManager.addAttendee(title, username);
            if (successfulSignup) {
                signUpPresenter.display(SignUpPrompts.SUCCESSFUL_SIGNUP_PROMPT);
            } else if (!eventManager.isNotFull(title)) {
                signUpPresenter.display(SignUpPrompts.EVENT_FULL_ERROR);
            }
        } catch (EventNotFoundException e) {
            signUpPresenter.display(SignUpPrompts.EVENT_NOT_FOUND_ERROR);
        }
    }

    /**
     * Processes a user's request to cancel their attendance in an event.
     *
     * @param username The username of the currently logged in user
     */
    public void cancelSpotInEvent(String username) {
        signUpPresenter.display(SignUpPrompts.CANCEL_SIGNUP_PROMPT);
        String title = in.nextLine();
        try {
            boolean successfulCancellation = eventManager.removeAttendee(title, username);
            if (successfulCancellation) {
                signUpPresenter.display(SignUpPrompts.SUCCESSFUL_CANCELLATION_PROMPT);
            } else if (!eventManager.getAttendees(title).contains(username)) {
                signUpPresenter.display(SignUpPrompts.NOT_REGISTERED);
            }
        } catch (EventNotFoundException e) {
            signUpPresenter.display(SignUpPrompts.EVENT_NOT_FOUND_ERROR);
        }
    }
}