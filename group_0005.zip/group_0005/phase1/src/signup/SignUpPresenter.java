package signup;

import system.ConsolePresenter;

import java.util.EnumMap;
import java.util.List;

/**
 * The SignUpPresenter class is responsible for displaying the messages related to signing up for events, that are to
 * be printed on the screen.
 */
class SignUpPresenter extends ConsolePresenter<SignUpPrompts> {

    /**
     * Returns an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     *
     * @return an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     */
    @Override
    protected EnumMap<SignUpPrompts, String> initializeMessages() {
        EnumMap<SignUpPrompts, String> m = new EnumMap<>(SignUpPrompts.class);
        m.put(SignUpPrompts.EVENT_SEARCH_PROMPT,
                "Enter a Start Time, Title, or Speaker to search for the events by:");
        m.put(SignUpPrompts.SIGNUP_PROMPT, "Please enter an event title to sign up for:");
        m.put(SignUpPrompts.SUCCESSFUL_SIGNUP_PROMPT,
                "You have successfully signed up for the event.");
        m.put(SignUpPrompts.CANCEL_SIGNUP_PROMPT,
                "Please enter an event title to cancel your registration in:");
        m.put(SignUpPrompts.SUCCESSFUL_CANCELLATION_PROMPT,
                "You have successfully cancelled your attendance in the event.");
        m.put(SignUpPrompts.NOT_REGISTERED, "You are not registered in this event. please try again.");
        m.put(SignUpPrompts.EVENT_FULL_ERROR, "You could not sign up for the event because the event is full.");
        m.put(SignUpPrompts.EVENT_NOT_FOUND_ERROR, "No events were found with the given information.");
        m.put(SignUpPrompts.SPEAKER_SIGN_UP_ERROR, "You cannot sign up for an event you are the speaker for!");
        m.put(SignUpPrompts.ALREADY_SIGNED_UP, "You are already signed up for this event!");
        m.put(SignUpPrompts.CHOOSE_FILTER, "Choose a filter to search for the events by: \n 1 - Event Title \n " +
                "2 - Event Speaker \n 3 - Event Start Time \n 4 - Return to the main menu");
        m.put(SignUpPrompts.ENTER_TITLE_PROMPT, "Enter the Title of an event to search by: ");
        m.put(SignUpPrompts.ENTER_SPEAKER_PROMPT, "Enter the Speaker of an event to search by: ");
        m.put(SignUpPrompts.ENTER_TIME_PROMPT, "Enter the Start Time of the event to search by: ");
        m.put(SignUpPrompts.INVALID_INPUT, "Invalid input, please try again.");
        m.put(SignUpPrompts.INVALID_TIME, "Invalid start time entered. Please enter a number for the time. ");
        return m;
    }

    /**
     * Prints all the events in a given list.
     *
     * @param events A list of events
     */
    public void showFilteredEvents(List<String> events) {
        for (String eventString : events) {
            System.out.println(eventString);
        }
    }

}