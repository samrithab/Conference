package room;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * This class represents a Room in the conference.
 */
class Room implements Serializable {

    private final int roomID;
    private final int capacity;
    private final List<String> eventTitles;
    private final List<Integer> bookedTimes;

    /**
     * Constructs a new Room that stores an initially empty list of eventIDs for each Event in this room, as well
     * as another list for each Event's corresponding startTime.
     *
     * @param roomID   the unique room number of this room.
     * @param capacity the maximum number of attendees this room can hold.
     */
    public Room(int roomID, int capacity) {
        this.roomID = roomID;
        this.capacity = capacity;
        this.eventTitles = new ArrayList<>();
        this.bookedTimes = new ArrayList<>();
    }

    /**
     * Gets the unique ID (the room number) for this Room, which is used to refer to this Room.
     *
     * @return the roomID for this Message
     */
    public int getRoomID() {
        return this.roomID;
    }

    /**
     * Gets the capacity (the maximum number of attendees) of this Room.
     *
     * @return the capacity for this Room
     */
    public int getCapacity() {
        return this.capacity;
    }

    /**
     * Gets the list of times in which this Room is currently booked for.
     *
     * @return the list of times that are currently booked for this Room
     */
    public List<Integer> getBookedTimes() {
        return this.bookedTimes;
    }

    /**
     * Adds an event to this Room.
     *
     * @param eventTitle the title of the Event to be added
     */
    public void addEvent(String eventTitle) {
        eventTitles.add(eventTitle);
    }

    /**
     * Adds a time to be booked for this Room.
     *
     * @param startTime the time of the Event in which this Room is booked for
     */
    public void addBookedTime(int startTime) {
        bookedTimes.add(startTime);
    }
}

