package room;

import java.util.Map;
import java.util.OptionalInt;
import java.util.Scanner;

/**
 * The RoomController class is responsible for processing requests involving ...
 */
public class RoomController {

    private final RoomManager roomManager;
    private final RoomPresenter roomPresenter;
    private final Scanner in;

    /**
     * Creates a new RoomController with the given <code>RoomManager</code>.
     *
     * @param roomManager a manager that manages <code>Room</code> entities
     * @param in          the instance of Scanner currently looking at the Console
     */
    public RoomController(RoomManager roomManager, Scanner in) {
        this.roomManager = roomManager;
        this.roomPresenter = new RoomPresenter();
        this.in = in;
    }

    /**
     * Processes an organizer's request to enter a new room into the system.
     * This method accepts information regarding the new room, checks if this information is valid,
     * and calls for the creation of the new room if so.
     */
    public void enterNewRoom() {
        // Process room ID
        OptionalInt roomID = readInteger(RoomPrompts.ROOM_ID_PROMPT);
        if (!roomID.isPresent() || invalidRoomToAdd(roomID.getAsInt())) {
            return;
        }
        // Process room capacity
        OptionalInt roomCapacity = readInteger(RoomPrompts.ROOM_CAPACITY_PROMPT);
        if (!roomCapacity.isPresent() || invalidRoomCapacity(roomCapacity.getAsInt())) {
            return;
        }
        roomManager.createNewRoom(roomID.getAsInt(), roomCapacity.getAsInt());
        roomPresenter.display(RoomPrompts.ROOM_ADDED_SUCCESS);
    }

    private OptionalInt readInteger(RoomPrompts prompt) {
        roomPresenter.display(prompt);
        if (!in.hasNextInt()) {
            roomPresenter.display(RoomPrompts.INVALID_NUM_ERROR);
            in.nextLine();
            return OptionalInt.empty();
        }
        int input = in.nextInt();
        in.nextLine();
        return OptionalInt.of(input);
    }

    private boolean invalidRoomToAdd(int roomID) {
        if (roomID <= 0) {
            roomPresenter.display(RoomPrompts.INVALID_NUM_ERROR);
            return true;
        } else if (roomManager.roomExists(roomID)) {
            roomPresenter.display(RoomPrompts.ROOM_EXISTS_ERROR);
            return true;
        }
        return false;
    }

    private boolean invalidRoomCapacity(int roomCapacity) {
        if (roomCapacity <= 0) {
            roomPresenter.display(RoomPrompts.INVALID_NUM_ERROR);
            return true;
        }
        return false;
    }

    /**
     * Processes the user's request to view all rooms entered in the system.
     * This method results in the output of the room numbers and capacity of all rooms.
     */
    public void viewRooms() {
        Map<Integer, Integer> roomInformation = roomManager.getRoomInformation();
        roomPresenter.displayRoomInformation(roomInformation);
    }
}
