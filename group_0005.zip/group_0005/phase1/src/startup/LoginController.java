package startup;

import javafx.util.Pair;
import user.UserManager;

import java.util.Scanner;

/**
 * The LoginController class is responsible for processing the user's request to log in.
 * It accepts the user's inputted login credentials and looks for a match to an existing account until one is found.
 */
class LoginController {

    private final LoginPresenter loginPresenter;
    private final UserManager userManager;
    private final Scanner in;

    /**
     * Constructs a controller to process the current user's login attempts.
     *
     * @param userManager the manager responsible for user data during program execution
     * @param in          the instance of Scanner currently looking at the Console
     */
    public LoginController(UserManager userManager, Scanner in) {
        this.loginPresenter = new LoginPresenter();
        this.userManager = userManager;
        this.in = in;
    }

    /**
     * Returns the username of the account that the user has successfully logged in to.
     * This method reads in the user's inputted login credentials until the input matches an existing account.
     *
     * @return the username of the account successfully logged in to
     */
    public String login() {
        Pair<String, String> credentials = inputCredentials();
        while (usernameIsInvalid(credentials.getKey()) || passwordIsInvalid(credentials)) {
            if (usernameIsInvalid(credentials.getKey())) {
                loginPresenter.display(LoginPrompts.NO_SUCH_USERNAME);
            } else {
                loginPresenter.display(LoginPrompts.WRONG_PASSWORD);
            }
            credentials = inputCredentials();
        }
        loginPresenter.displaySuccessMessage(credentials.getKey());
        return credentials.getKey();
    }

    private Pair<String, String> inputCredentials() {
        loginPresenter.display(LoginPrompts.USERNAME_PROMPT);
        String username = in.nextLine();
        if (usernameIsInvalid(username)) { /* prevent input from continuing if username is already invalid */
            return new Pair<>(username, "");
        }
        loginPresenter.display(LoginPrompts.PASSWORD_PROMPT);
        String password = in.nextLine();
        return new Pair<>(username, password);
    }

    private boolean usernameIsInvalid(String username) {
        return username.equals("") || !userManager.userExists(username);
    }

    private boolean passwordIsInvalid(Pair<String, String> credentials) {
        return credentials.getValue().equals("") ||
                !userManager.passwordMatches(credentials.getKey(), credentials.getValue());
    }

}
