package startup;

import system.ConsolePresenter;

import java.util.EnumMap;

/**
 * This class presents messages to the user and provides the UI during login.
 */
class LoginPresenter extends ConsolePresenter<LoginPrompts> {

    /**
     * Returns an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     *
     * @return an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     */
    @Override
    protected EnumMap<LoginPrompts, String> initializeMessages() {
        EnumMap<LoginPrompts, String> m = new EnumMap<>(LoginPrompts.class);
        m.put(LoginPrompts.USERNAME_PROMPT, "Please enter your username:");
        m.put(LoginPrompts.NO_SUCH_USERNAME,
                "Sorry, an account with that username was not found. Please try again.");
        m.put(LoginPrompts.PASSWORD_PROMPT, "Please enter your password:");
        m.put(LoginPrompts.WRONG_PASSWORD,
                "Sorry, that password does not match our records. Please try again.");
        return m;
    }

    /**
     * Displays a success message greeting the user who logged in
     *
     * @param username the username of the logged in user
     */
    public void displaySuccessMessage(String username) {
        System.out.println("Welcome back, " + username + "!");
    }
}
