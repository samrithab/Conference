package startup;

/**
 * This enum contains keys specifying the one-line text prompts that can be printed
 * to console during interactions in <code>LoginController</code>.
 */
enum LoginPrompts {

    USERNAME_PROMPT,
    NO_SUCH_USERNAME,
    PASSWORD_PROMPT,
    WRONG_PASSWORD

}
