package startup;

import user.UserManager;
import user.UserType;

import java.util.Scanner;

/**
 * This class interacts with the user to facilitate account creation.
 */
public class AccountCreationController {

    private final Scanner in;
    private final AccountCreationPresenter presenter;
    private final UserManager userManager;

    /**
     * Creates a new <code>AccountCreationController</code> object.
     *
     * @param userManager a <code>UserManager</code> object containing all users
     * @param in          a <code>Scanner</code> object to be used for taking input
     */
    public AccountCreationController(UserManager userManager, Scanner in) {
        this.userManager = userManager;
        this.presenter = new AccountCreationPresenter();
        this.in = in;
    }

    /**
     * Creates a new user account according to user input.
     */
    public void createAccount() {
        String username = solicitUsername();
        String password = solicitPassword();
        UserType userType = solicitUserType();
        userManager.addUser(username, password, userType);
    }

    /**
     * Creates a new speaker account according to user input.
     */
    public void createSpeakerAccount() {
        String username = solicitUsername();
        String password = solicitPassword();
        UserType userType = UserType.SPEAKER;
        userManager.addUser(username, password, userType);
    }

    private String solicitUsername() {
        while (true) {
            presenter.display(AccountCreationPrompts.USERNAME_PROMPT);
            String username = in.nextLine();
            if (userManager.userExists(username)) {
                presenter.display(AccountCreationPrompts.USERNAME_IN_USE);
            } else {
                return username;
            }
        }
    }

    private String solicitPassword() {
        String password = "";
        while (password.isEmpty()) {
            presenter.display(AccountCreationPrompts.PASSWORD_PROMPT);
            password = in.nextLine();
        }
        return password;
    }

    private UserType solicitUserType() {
        while (true) {
            UserType[] choices = new UserType[]{UserType.ATTENDEE, UserType.ORGANIZER, UserType.SPEAKER};
            presenter.display(AccountCreationPrompts.USERTYPE_PROMPT);
            presenter.displayUserTypeChoices(choices);
            String selection = in.nextLine();
            try {
                int select = Integer.parseInt(selection);
                if (select >= 0 && select < choices.length) {
                    return choices[Integer.parseInt(selection)];
                } else {
                    presenter.display(AccountCreationPrompts.INVALID_USERTYPE);
                }
            } catch (NumberFormatException e) {
                presenter.display(AccountCreationPrompts.INVALID_USERTYPE);
            }
        }
    }
}
