package startup;

import system.ConsolePresenter;

import java.util.EnumMap;

/**
 * The StartUpPresenter class is responsible for displaying messages that appear when the program first begins.
 * Its primary task is to provide the user with the initial menu of actions.
 */
class StartUpPresenter extends ConsolePresenter<StartUpPrompts> {

    /**
     * Returns an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     *
     * @return an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     */
    @Override
    protected EnumMap<StartUpPrompts, String> initializeMessages() {
        EnumMap<StartUpPrompts, String> m = new EnumMap<>(StartUpPrompts.class);
        m.put(StartUpPrompts.WELCOME_MESSAGE, "Welcome! Please enter a command.");
        m.put(StartUpPrompts.INPUT_ERROR, "Sorry, your input was invalid. Please enter '1', '2', or '3'.");
        return m;
    }

    /**
     * Displays the menu of initial actions the user can do upon program start up.
     */
    public void displayStartUpMenu() {
        System.out.println("1 - Create a new account ");
        System.out.println("2 - Login to an existing account");
        System.out.println("3 - Quit Program");
    }

}
