package startup;

import gateway.GatewaysObject;
import system.ManagerParameterObject;
import system.SystemController;
import system.SystemControllerFactory;
import user.UserType;

import java.util.Scanner;

/**
 * This class is responsible for coordinating the controllers and gateways that are used on program startup.
 */
public class StartUpController {
    private final Scanner in;
    private final SystemControllerFactory factory;
    private final StartUpPresenter startUpPresenter;
    private final LoginController loginController;
    private final AccountCreationController accountCreationController;
    private final GatewaysObject gateways;
    private final ManagerParameterObject managers;

    /**
     * Creates a new <code>StartUpController</code> object.
     */
    public StartUpController() {
        this.in = new Scanner(System.in);
        gateways = new GatewaysObject();
        managers = gateways.getManagers();
        startUpPresenter = new StartUpPresenter();
        loginController = new LoginController(managers.getUserManager(), in);
        accountCreationController = new AccountCreationController(managers.getUserManager(), in);
        factory = new SystemControllerFactory();
    }

    /**
     * Processes the user's initial input, runs the program as long as the user has not selected to quit, and writes
     * the program's data to files.
     */
    public void run() {
        boolean quit = processInitialRequest();
        while (!quit) {
            String username = loginController.login();
            UserType userType = managers.getUserManager().getUserType(username);
            SystemController system = factory.createSystemController(userType, managers, username, in);
            system.run();
            quit = processInitialRequest();
        }
        gateways.writeManagers(managers);
    }

    /**
     * Processes the user's initial input regarding whether to create an account, log in, or quit.
     *
     * @return <code>true</code> if and only if the user has selected to quit
     */
    private boolean processInitialRequest() {
        startUpPresenter.display(StartUpPrompts.WELCOME_MESSAGE);
        startUpPresenter.displayStartUpMenu();
        String input;
        while (true) {
            input = in.nextLine();
            switch (input) {
                case "1":
                    accountCreationController.createAccount();
                    // Display the main menu again after account creation
                    return processInitialRequest();
                case "2":
                    return false;
                case "3":
                    return true;
                default:
                    startUpPresenter.display(StartUpPrompts.INPUT_ERROR);
                    startUpPresenter.displayStartUpMenu();
                    break;
            }
        }
    }
}
