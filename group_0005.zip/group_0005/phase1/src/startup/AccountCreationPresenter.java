package startup;

import system.ConsolePresenter;
import user.UserType;

import java.util.EnumMap;

/**
 * This class presents messages to the user and provides the UI during account creation.
 */
class AccountCreationPresenter extends ConsolePresenter<AccountCreationPrompts> {

    /**
     * Returns an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     *
     * @return an <code>EnumMap</code> that maps each enum key of type <code>T</code> to its respective console message
     */
    @Override
    protected EnumMap<AccountCreationPrompts, String> initializeMessages() {
        EnumMap<AccountCreationPrompts, String> m = new EnumMap<>(AccountCreationPrompts.class);
        m.put(AccountCreationPrompts.USERNAME_PROMPT, "Please enter a username:");
        m.put(AccountCreationPrompts.USERNAME_IN_USE,
                "That username is already in use. Please choose a different username.");
        m.put(AccountCreationPrompts.PASSWORD_PROMPT, "Please enter a password:");
        m.put(AccountCreationPrompts.USERTYPE_PROMPT, "Please choose your user type.");
        m.put(AccountCreationPrompts.INVALID_USERTYPE, "Invalid selection. Please enter a valid choice.");
        return m;
    }

    /**
     * Displays a menu for the given choices.
     *
     * @param choices an array of choices
     */
    public void displayUserTypeChoices(UserType[] choices) {
        for (int i = 0; i < choices.length; ++i) {
            System.out.println("" + i + " - " + choices[i].toString());
        }
    }

}
