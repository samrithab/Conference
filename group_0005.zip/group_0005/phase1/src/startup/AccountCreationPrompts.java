package startup;

/**
 * This enum contains keys specifying the one-line text prompts that can be printed
 * to console during interactions in <code>AccountCreationController</code>.
 */
enum AccountCreationPrompts {

    USERNAME_PROMPT,
    USERNAME_IN_USE,
    PASSWORD_PROMPT,
    USERTYPE_PROMPT,
    INVALID_USERTYPE,
    PASSWORD_NO_LENGTH

}
